/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=26x160 top_pipe top_pipe_final.png 
 * Time-stamp: Tuesday 04/04/2023, 19:42:04
 * 
 * Image Information
 * -----------------
 * top_pipe_final.png 26@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TOP_PIPE_H
#define TOP_PIPE_H

extern const unsigned short top_pipe_final[4160];
#define TOP_PIPE_FINAL_SIZE 8320
#define TOP_PIPE_FINAL_LENGTH 4160
#define TOP_PIPE_FINAL_WIDTH 26
#define TOP_PIPE_FINAL_HEIGHT 160

#endif

