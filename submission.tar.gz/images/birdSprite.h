/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=32x23 birdSprite birdSprite.png 
 * Time-stamp: Tuesday 04/04/2023, 17:44:09
 * 
 * Image Information
 * -----------------
 * birdSprite.png 32@23
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIRDSPRITE_H
#define BIRDSPRITE_H

extern const unsigned short birdSprite[736];
#define BIRDSPRITE_SIZE 1472
#define BIRDSPRITE_LENGTH 736
#define BIRDSPRITE_WIDTH 32
#define BIRDSPRITE_HEIGHT 23

#endif

