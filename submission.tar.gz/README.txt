Hello, This is my Flappy Bird-Like Game!

Basic Controls:
Enter game: Enter key.
Return to main menu: Backspace key.
Up: Up Arrow key
Down: Down Arrow key
Left: Left Arrow key
Right: Right Arrow key

The game gets faster after 10 points are scored and ends when 50 points are scored.

Thanks for playing!
